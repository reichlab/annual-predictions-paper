#!/bin/bash
echo $REXE
if [ -z ${REXE}]
then
REXE=Rscript
fi
echo $REXE
## put together forecasting data from raw data
$REXE R/make-forecasting-data.R > data/make-forecasting-data-output.Rout
## conduct cross validation, model selection, and test phase forecasts
$REXE R/make-forecasts.R > data/make-forecasts.Rout
## make the figures for the manuscript
$REXE -e "library(knitr);knit2pdf('manuscript/Lauer-annual-DHF-figures.Rnw')"
## make the supplement
$REXE -e "library(knitr);knit2pdf('manuscript/Lauer-annual-DHF-supplement.Rnw')"
## make the manuscript
$REXE -e "library(knitr);knit2pdf('manuscript/Lauer-annual-DHF-manuscript.Rnw')"
