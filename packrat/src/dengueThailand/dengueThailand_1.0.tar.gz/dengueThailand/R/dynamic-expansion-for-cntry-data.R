## functions for dynamic expansion of case counts for prediction
## Nicholas Reich, Stephen Lauer, Krzysztof Sakrejda

##TODO: apply dynamic expansion to linelist

#' Apply dynamic expansion to a cntry.data object.
#'
#' @param cntry_data cntry.data object
#' @param last_yr_active logical, whether reports still being delivered for the last calendar year
#' @param last_yr_complete logical, whether last calendar year of data is fully reported, must provide if last_yr_active==F
#' @param last_yr_active_biweek numeric, last biweek for which cases were reported for the prior year, must provide if last_yr_active==F (may be provided instead of last_yr_active)
#' @param last_yr_complete_biweek numeric,  biweek of the final data dump completing the prior year. May be used instead of last_yr_complete
#' @param analysis_biweek numeric, biweek in which the analysis is being run
#' @param analysis_date date, when analysis is run; will be used to find analysis_biweek
#' @param expanded_counts_file logical, whether to return a file with expanded counts separate
#' @param expand_dat character string, name of the data to use for expansion ("thai_dynamic_expansion_probs" to use model fit or "thai_empirical_expansion_probs" to use the 2014 observed values)
#' @param time_in_biweek numeric, days since the start of the biweek that data were delivered
#' @param delivery_date date, date when the most recent data were delivered
#' @param delivery_biweek numeric, biweek in which the data were delivered
#'
#' @return a cntry.data object with counts expanded at the end
expand_cntry_data <- function(cntry_data,
                              last_yr_active,
                              last_yr_complete,
                              last_yr_active_biweek,
                              last_yr_complete_biweek,
                              analysis_date,
                              analysis_biweek,
                              delivery_date,
                              delivery_biweek,
                              time_in_biweek,
                              expanded_counts_file=FALSE,
                              expand_dat="thai_dynamic_expansion_probs") {
    require(spatialpred)
    require(dengueThailand)
    require(lubridate)

    if(missing(analysis_date) & missing(analysis_biweek))
        stop("Please specify either analysis_date or analysis_biweek")
    if(missing(analysis_date)){
        warning("Assuming analysis takes place in current year. If not, please specify analysis_date")
        analysis_date <- biweek_to_date(analysis_biweek, year(Sys.Date()))
    }
    if(missing(analysis_biweek)){
        analysis_biweek <- date_to_biweek(analysis_date)
    }
    if(missing(delivery_date)){
        warning("Assuming analysis takes place in current year. If not, please specify analysis_date")
        delivery_date <- analysis_date
    }
    if(missing(delivery_biweek)){
        delivery_biweek <- date_to_biweek(delivery_date)
    }
    if(missing(time_in_biweek)){
        time_in_biweek <- delivery_date-biweek_to_date(delivery_biweek,
                                                       year(delivery_date))
        time_in_biweek <- time_in_biweek[[1]]
    }
    if(missing(last_yr_active_biweek) & missing(last_yr_active))
        stop("Please specify either last_yr_active_biweek or last_yr_active.")
    if(missing(last_yr_complete_biweek) & missing(last_yr_complete))
        stop("Please specify either last_yr_complete_biweek or last_yr_complete=TRUE.")
    if(missing(last_yr_active))
        last_yr_active <- analysis_biweek<=last_yr_active_biweek
    if(missing(last_yr_complete))
        last_yr_complete <- analysis_biweek>=last_yr_complete_biweek

    ## if last_yr_active == TRUE, we need analysis_biweek - 1 + 26 thetas
    if(last_yr_active){
        thetas <- calculate_expansion_probs(n_expansions=analysis_biweek-1+26,
                                            time_in_biweek=time_in_biweek
                                            # ,expand_dat
                                            )
    } else{
        ## if  last_yr_active == FALSE and last_yr_complete == TRUE, we need analysis_biweek - 1 thetas
        if(last_yr_complete){
            thetas <- calculate_expansion_probs(n_expansions=analysis_biweek-1,
                                                time_in_biweek=time_in_biweek
                                                # ,expand_dat
                                                )
        } else{
            ## if  last_yr_active == FALSE and last_yr_complete == FALSE, we need separate thetas for each year
            if(analysis_biweek<=last_yr_active_biweek)
                stop("If analysis_biweek <= last_yr_active_biweek, last year is still active. Please set last_yr_active=TRUE.")

            ## calculate the thetas for the current year
            theta_current <- calculate_expansion_probs(n_expansions=analysis_biweek-1,
                                                       time_in_biweek=time_in_biweek
                                                       # ,expand_dat
                                                       )

            ## calculate the thetas for last year (assuming max time_in_biweek)
            theta_last_yr <- calculate_expansion_probs(
                n_expansions=26+last_yr_active_biweek,
                time_in_biweek=14
                # ,expand_dat
            )
            thetas <- cbind(theta_last_yr[,1:26], theta_current)
        }
    }

    ## change colnames to time since analysis date
    colnames(thetas) <- year(analysis_date)+analysis_biweek/26-(ncol(thetas):1+1)/26

    ## calculate median expansions
    calculate_expansions(cntry_data, thetas, expanded_counts_file)
}

#' Calculation of expansions for
#'
#' @param cntry_data cntry.data object
#' @param thetas output from calculate_expansion_probs(), probs for NBinom distribution
#' @param expanded_counts_file logical, whether to return a file with expanded counts separate
#'
#' @return cntry.data object with expanded counts
calculate_expansions <- function(cntry_data,
                                 thetas,
                                 expanded_counts_file) {
    require(dengueThailand)
    data(thai_prov_data)

    ## check that all provinces are represented in both params
    #     cntry_data_pids <- data.frame(Province = cntry_data@names) %>%
    #         left_join(thai_prov_data) %>% select(pid)
    #     theta_pids <- thetas$pid

    ## extract only most recent columns
    cols_to_keep <- which(cntry_data@t %in% colnames(thetas))
    data_to_expand <- cntry_data@.Data[,cols_to_keep]
    colnames(data_to_expand) <- cntry_data@t[cols_to_keep]
    thetas_to_use <- thetas[,which(colnames(thetas) %in%
                                       colnames(data_to_expand))]
    expand_data <- pmax(ceiling(qnbinom(p = 0.5, size = data_to_expand,
                                        prob = thetas_to_use)),0)

    ## merge data back
    cntry_data@.Data[,cols_to_keep] <- cntry_data@.Data[,cols_to_keep] +
        expand_data

    if(expanded_counts_file)
        return(list(cntry_data=cntry_data, expand_data=expand_data)) else
            return(cntry_data=cntry_data)
}


#' Calculate dynamic expansion probabilities
#'
#' @param n_expansions numeric, number of biweeks back to expand
#' @param expand_dat character string, name of the data to use for expansion ("thai_dynamic_expansion_probs" to use model fit or "thai_empirical_expansion_probs" to use the 2014 observed values)
#'
#' @return prob_matrix a matrix of dynamic expansion probabilities for each province by lag
#' @export
#'
#' @examples calculate_expansion_probs(13)
calculate_expansion_probs <-
    function(n_expansions,
             time_in_biweek#,
             # expand_dat="thai_dynamic_expansion_probs"
             ){

        require(dengueThailand)
        require(dplyr)
        require(tidyr)
        ## read in data with pid info
        data("thai_prov_data")
        ## read in potential theta tables
        data("thai_dynamic_expansion_probs")
        # data("thai_empirical_expansion_probs")

        ## convert number of biweeks back into days (quick and dirty)
        days_back <- round(0:(n_expansions-1)*(14+1/26))+time_in_biweek

        ## adjust theta table so that oldest thetas come first
        thai_dynamic_expansion_probs$days <-
            factor(thai_dynamic_expansion_probs$days)
        thai_dynamic_expansion_probs$days <-
            factor(thai_dynamic_expansion_probs$days,
                   levels=rev(levels(thai_dynamic_expansion_probs$days)))

        ## create matrix of thetas with pid on left, oldest thetas on left newest on right
        prob_matrix <- thai_dynamic_expansion_probs %>%
            filter(days %in% days_back,
                   geocode_province != 38) %>%
            mutate(province =
                       thai_prov_data$Province[match(geocode_province,
                                                     thai_prov_data$ISO)]) %>%
            spread(days, p) %>%
            ungroup() %>%
            select(-geocode_province)

        prob_matrix_rows <- prob_matrix$province
        prob_matrix <- as.matrix(prob_matrix[,-1])
        rownames(prob_matrix) <- prob_matrix_rows
        colnames(prob_matrix) <- paste0("theta", n_expansions:1)

        return(as.matrix(prob_matrix))
    }
