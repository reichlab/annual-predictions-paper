##' @name thai_prov_data
##' @title Data on provinces in Thailand
##' @description A data frame with information about Thai provinces, including different identifiers, an English language name, region, area, and population (based on the 2010 census). Geographical regions from Wikipedia. Longitude and latitude are derived from the spatial polygons object of Thailand.
##' @docType data
##' @format A data frame.
##'
##' @usage data(thai_prov_data)
##' @source 2010 census data, accessed: 10 April 2014 \url{http://www.statoids.com/uth.html}. Wikipedia: Regions of Thailand, accessed: 22 February 2016 \url{https://en.wikipedia.org/wiki/Regions_of_Thailand}.
##'
##' @examples
##' data(thai_prov_data)
##' @keywords datasets
NULL

##' @name thai_prov_data2
##' @title Data on provinces in Thailand (updated)
##' @description A data frame with information about Thai provinces, including different identifiers, an English language name, region, area, and population (based on the 2010 census). Geographical regions from Wikipedia. Longitude and latitude are derived from the spatial polygons object of Thailand. Also includes data regarding split provinces.
##' @docType data
##' @format A data frame.
##'
##' @usage data(thai_prov_data2)
##' @source 2010 census data, accessed: 10 April 2014 \url{http://www.statoids.com/uth.html}. Wikipedia: Regions of Thailand, accessed: 22 February 2016 \url{https://en.wikipedia.org/wiki/Regions_of_Thailand}. GeoNames: ISO Subentity Codes for Thailand, accessed: 20 May 2016 \url{http://www.geonames.org/TH/administrative-division-thailand.html}
##'
##' @examples
##' data(thai_prov_data2)
##' @keywords datasets
NULL

##' @name thai_dynamic_expansion_probs
##' @title The dynamic expansion probabilities for each in Thailand
##' @description A data frame with the ISO number for each province, the number of days in the past (from 0 to 485) and the dynamic expansion probability for each province-time combination.
##' @docType data
##' @format A data frame.
##'
##' @usage data(thai_dynamic_expansion_probs)
##'
##' @examples
##' data(thai_dynamic_expansion_probs)
##' @keywords datasets
NULL

##' @name thai_census_raw
##' @title All of the raw census data for the provinces of Thailand
##' @description A data frame with the results of every census available for each province in Thailand.
##' @docType data
##' @format A data frame.
##'
##' @usage data(thai_census_raw)
##' @source Census data, accessed: 3 February 2017 \url{http://www.statoids.com/uth.html}.
##'
##' @examples
##' data(thai_census_raw)
##' @keywords datasets
NULL

##' @name thai_census_interpolated
##' @title Interpolated annual populations for the provinces of Thailand based on census data
##' @description A data frame with interpolated populations for each province in Thailand based on census data (which can be found in \code{data(thai_census_raw)}). All populations between two censuses are assumed to grow at the same rate. Populations after the final census (2010) are assumed to continue growing at the same rate as from 2000-2010.
##'
##' Split provinces grow at a rate assuming that the provinces would not split (i.e. the pre-split parent census population grows towards the sum of the split provinces post-split census populations). Splits are determined by the date when we first receive dengue data from a province, not by the actual split date.
##' @docType data
##' @format A data frame.
##'
##' @usage data(thai_census_interpolated)
##' @source Census data, accessed: 3 February 2017 \url{http://www.statoids.com/uth.html}.
##'
##' @examples
##' data(thai_census_interpolated)
##' @keywords datasets
NULL
