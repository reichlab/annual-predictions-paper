#' Find Thai annual population
#' Interpolates populations between census dates.
#'
#' Notes: Thon Buri is merged with Bangkok for all years (though were not merged until 1971). Pre-1999 populations for Mukdahan are merged with Nakhon Phanom (since no DHF counts or FIPS for Mukdahan until 1999).
#'
#' @param first_year first year of interest
#' @param last_year last year of interest, if unspecified is present year
#'
#' @return data frame with province, year, and population
find_annual_population <- function(first_year,
                                   last_year,
                                   really_run=F) {
    if(really_run==F)
        stop("The function is no longer necessary to run. The output file can be found using data(thai_census_interpolated). If you really want to run this code, set really_run=T")

    require(XML)
    require(tidyr)
    require(dplyr)
    require(lubridate)

    if(missing(last_year))
        last_year <- year(Sys.Date())

    data("thai_prov_data2")
    thai_prov_data2 <- thai_prov_data2[1:77,]

    ## find the population for each province in each year for their FIPS at that time
    census_dat <- readHTMLTable("http://www.statoids.com/uth.html",
                                which=3,
                                stringsAsFactors=FALSE) %>%
        gather("variable", "value", 2:8) %>%
        mutate(year=year(as.Date(variable)),
               population=as.numeric(gsub(",", "", value))) %>%
        left_join(select(thai_prov_data2, -population),
                  by=c("Province"="province")) %>%
        mutate(pid=ifelse(year<1999, ## some provinces changed FIPS in 1999
                          as.character(fips_1998),
                          as.character(fips)),
               pid=ifelse(first_data_year!=1968&
                              year<first_data_year, ## for provinces that split before 1999
                          as.character(parent_fips),
                          pid),
               pid=ifelse(Province=="Thon Buri", ## merge Thon Buri with BKK
                          "TH40",
                          pid),
               province=ifelse(first_data_year!=1968&
                                   year<first_data_year,
                               as.character(family),
                               as.character(Province)),
               province=ifelse(Province=="Thon Buri",
                               "Bangkok Metropolis",
                               province)) %>%
        group_by(province, pid, year) %>%
        summarise(population=sum(population, na.rm=T)) %>%
        ungroup()

    ## find year 2000 populations for provinces split in 1999
    # split_census_dat <- readHTMLTable("http://www.statoids.com/uth.html",
    #                                   which=3,
    #                                   stringsAsFactors=FALSE) %>%
    #     gather("variable", "value", 2:8) %>%
    #     mutate(year=year(as.Date(variable)),
    #            population=as.numeric(gsub(",", "", value))) %>%
    #     left_join(select(thai_prov_data2, -population),
    #               by=c("Province"="province")) %>%
    #     filter(year==2000,
    #            split==TRUE) %>%
    #     mutate(pid=ifelse(is.na(fips_1998),
    #                       as.character(parent_fips),
    #                       as.character(fips_1998)),
    #            province=ifelse(is.na(fips_1998),
    #                            as.character(family),
    #                            as.character(Province))) %>%
    #     group_by(province, pid, year) %>%
    #     summarise(population=sum(population, na.rm=T)) %>%
    #     ungroup()

    ## bind census data into single data frame
    thai_census_dat <- census_dat %>%
        # bind_rows(census_dat, split_census_dat) %>%
        distinct() %>%
        group_by(pid) %>%
        filter(population>0,
               !is.na(pid),
               year>=ifelse(10*(floor((first_year-1)/10))>=max(year),
                            max(year)-10,
                            10*(floor((first_year-1)/10))),
               year<=ifelse(10*(ceiling((last_year)/10))<=min(year),
                            min(year)+13,
                            10*(ceiling((last_year)/10)))) %>%
        ungroup()

    ## create a data frame of all interpolated populations
    annual_population <- c()
    tmp_prov <- unique(thai_census_dat$province)
    for(i in 1:length(tmp_prov)){
        ## look only at one province at a time
        prov_census_dat <-
            filter(thai_census_dat,
                   province%in%c(unique(tmp_prov)[i],
                                 as.character(thai_prov_data2$family[
                                     which(thai_prov_data2$province==
                                               unique(tmp_prov)[i])]),
                                 as.character(thai_prov_data2$province[
                                     which(thai_prov_data2$family==unique(tmp_prov)[i])]))) %>%
            mutate(
                first_data_year=thai_prov_data2$first_data_year[
                    match(province, thai_prov_data2$province)],
                parent.child=thai_prov_data2$parent.child[
                    match(province, thai_prov_data2$province)],
                last_split_year=thai_prov_data2$last_split_year[
                    match(province, thai_prov_data2$province)])
        tmp_dat <- c()
        ## if the province isn't a parent or child proceed
        if(is.na(prov_census_dat$parent.child[1])){
            for(j in 2:nrow(prov_census_dat)){
                ## look at two consecutive census dates
                year_1 <- sort(prov_census_dat$year)[j-1]
                year_2 <- sort(prov_census_dat$year)[j]
                ## find populations from each census date
                pop_1 <- prov_census_dat$population[
                    prov_census_dat$year==year_1]
                pop_2 <- prov_census_dat$population[
                    prov_census_dat$year==year_2]
                ## find annual rate of increase from early date to later date (negative means decreasing population)
                increase_rate <- (pop_2/pop_1)^(1/(year_2-year_1))

                ## create a data frame for the province between the two years of interest
                interp_df <- data_frame(province=prov_census_dat$province[1],
                                        pid=prov_census_dat$pid[j-1],
                                        year=seq(year_1, year_2 - 1), ## minus one so that don't duplicate years
                                        population=NA)

                ## for the last two census dates, have the year run to last_year
                ## (last_year+1) so data has at least two points to interpolate
                if(j==nrow(prov_census_dat)){
                    interp_df <- data_frame(province=prov_census_dat$province[1],
                                            pid=prov_census_dat$pid[j],
                                            year=seq(year_1, last_year+1),
                                            population=NA)
                }

                ## the first year should be the same as seen in the data
                interp_df$population[1] <- pop_1
                ## for remaining years just multiply by the increase rate
                for(k in 2:nrow(interp_df)){
                    interp_df$population[k] <- increase_rate*interp_df$population[k-1]
                }

                ## if first_year < the first census year, interpolate first rates backwards
                if(j==2&year_1>first_year) {
                    pre_df <- data_frame(province=prov_census_dat$province[1],
                                         pid=prov_census_dat$pid[j-1],
                                         year=seq(year_1, first_year, -1),
                                         population=NA)
                    ## the first year should be the same as seen in the data
                    pre_df$population[1] <- pop_1
                    ## for remaining years just divide by the increase rate
                    for(k in 2:nrow(pre_df)){
                        pre_df$population[k] <-  pre_df$population[k-1] / increase_rate
                    }
                    interp_df <- interp_df %>%
                        filter(year > year_1) %>%
                        bind_rows(pre_df) %>%
                        arrange(year)
                }
                tmp_dat <- bind_rows(tmp_dat,interp_df)
            }
        } else
            if(prov_census_dat$parent.child[which(prov_census_dat$province==tmp_prov[i])[1]]=="child"){
            child_data <- prov_census_dat %>%
                filter(province==tmp_prov[i])
            ## take only parent census data for dates pre- and post-split
            first_common_census <- min(prov_census_dat$year[
                which(duplicated(prov_census_dat$year))])
            prior_census <- max(prov_census_dat$year[
                which((prov_census_dat$year-first_common_census)<0)])
            parent_data <- prov_census_dat %>%
                filter(province!=tmp_prov[i],
                       year<=first_common_census,
                       year>=prior_census)

            for(j in 1:nrow(child_data)){
                if(j==1){
                    ## find year before and after split
                    year_1 <- min(parent_data$year)
                    year_2 <- max(parent_data$year)
                    ## find total population in pre- and post-split provinces
                    pop_1 <- parent_data$population[parent_data$year==year_1]
                    pop_2 <- parent_data$population[parent_data$year==year_2]+
                        child_data$population[child_data$year==year_2]
                    ## find growth rate for region
                    increase_rate <- (pop_2/pop_1)^(1/(year_2-year_1))
                    ## find the populations
                    interp_df <- data_frame(
                        province=child_data$province[1],
                        pid=child_data$pid[j],
                        year=seq(year_2, child_data$first_data_year[1], -1),
                        population=NA)
                    interp_df$population[1] <- child_data$population[
                        child_data$year==interp_df$year[1]]
                    for(k in 2:nrow(interp_df)){
                        interp_df$population[k] <- interp_df$population[k-1]/
                            increase_rate
                    }
                } else{
                    ## look at two consecutive census dates
                    year_1 <- sort(child_data$year)[j-1]
                    year_2 <- sort(child_data$year)[j]
                    ## find populations from each census date
                    pop_1 <- child_data$population[
                        child_data$year==year_1]
                    pop_2 <- child_data$population[
                        child_data$year==year_2]
                    ## find annual rate of increase from early date to later date (negative means decreasing population)
                    increase_rate <- (pop_2/pop_1)^(1/(year_2-year_1))

                    ## create a data frame for the province between the two years of interest
                    interp_df <- data_frame(province=child_data$province[1],
                                            pid=child_data$pid[j-1],
                                            year=seq(year_1, year_2-1), ## minus one so that don't duplicate years
                                            population=NA)

                    ## for the last two census dates, have the year run to last_year
                    ## (last_year+1) so data has at least two points to interpolate
                    if(j==nrow(child_data)){
                        interp_df <- data_frame(province=child_data$province[1],
                                                pid=child_data$pid[j],
                                                year=seq(year_1, last_year+1),
                                                population=NA)
                    }

                    ## the first year should be the same as seen in the data
                    interp_df$population[1] <- pop_1
                    ## for remaining years just multiply by the increase rate
                    for(k in 2:nrow(interp_df)){
                        interp_df$population[k] <- increase_rate*interp_df$population[k-1]
                    }
                }
                tmp_dat <- bind_rows(tmp_dat,interp_df)
            }
        } else {
            parent_data <- prov_census_dat %>%
                filter(province==tmp_prov[i])
            ## take only the first census from child_data
            child_data <- prov_census_dat %>%
                filter(province!=tmp_prov[i]) %>%
                group_by(province) %>%
                filter(year==min(year))
            for(j in 2:nrow(parent_data)){
                ## look at two consecutive census dates
                year_1 <- sort(parent_data$year)[j-1]
                year_2 <- sort(parent_data$year)[j]
                pop_1 <- parent_data$population[parent_data$year==year_1]
                if(year_2 %in% child_data$year){
                    ## use total of both provinces populations at latter census
                    pop_2 <- parent_data$population[parent_data$year==year_2]+
                        child_data$population[child_data$year==year_2]
                    increase_rate <- (pop_2/pop_1)^(1/(year_2-year_1))
                    ## interpolate populations up to province split
                    interp_df <- data_frame(
                        province=parent_data$province[j-1],
                        pid=parent_data$pid[j-1],
                        year=seq(year_1,
                                 child_data$first_data_year[
                                     child_data$year==year_2]-1),
                        population=NA)
                    interp_df$population[1] <- parent_data$population[
                        parent_data$year==interp_df$year[1]]
                    for(k in 2:nrow(interp_df)){
                        interp_df$population[k] <- interp_df$population[k-1]*
                            increase_rate
                    }
                    ## interpolate population back from latter census to split
                    decrease_rate <- (pop_1/pop_2)^(1/(year_2-year_1))
                    back_df <- data_frame(
                        province=parent_data$province[j],
                        pid=parent_data$pid[j],
                        year=seq(year_2,
                                 child_data$first_data_year[
                                     child_data$year==year_2]),
                        population=NA)
                    back_df$population[1] <- parent_data$population[
                        parent_data$year==back_df$year[1]]
                    for(k in 2:nrow(back_df)){
                        back_df$population[k] <- back_df$population[k-1]*
                            decrease_rate
                    }
                    interp_df <- interp_df %>%
                        bind_rows(back_df) %>%
                        filter(year < year_2) %>%
                        arrange(year)
                } else{
                    pop_2 <- parent_data$population[parent_data$year==year_2]
                    ## find growth rate for region
                    increase_rate <- (pop_2/pop_1)^(1/(year_2-year_1))
                    ## interpolate populations
                    interp_df <- data_frame(province=parent_data$province[1],
                                            pid=parent_data$pid[j-1],
                                            year=seq(year_1,
                                                     year_2-1),
                                            population=NA)
                    ## for the last two census dates, have the year run to last_year
                    ## (last_year+1) so data has at least two points to interpolate
                    if(j==nrow(parent_data)){
                        interp_df <- data_frame(province=parent_data$province[1],
                                                pid=parent_data$pid[j],
                                                year=seq(year_1, last_year+1),
                                                population=NA)
                    }

                    ## the first year should be the same as seen in the data
                    interp_df$population[1] <- pop_1
                    ## for remaining years just multiply by the increase rate
                    for(k in 2:nrow(interp_df)){
                        interp_df$population[k] <- increase_rate*interp_df$population[k-1]
                    }
                    interp_df$population[1] <- parent_data$population[
                        parent_data$year==interp_df$year[1]]
                    for(k in 2:nrow(interp_df)){
                        interp_df$population[k] <- interp_df$population[k-1]*
                            increase_rate
                    }

                    ## if first_year < the first census year, interpolate first rates backwards
                    if(j==2&year_1>first_year) {
                        pre_df <- data_frame(province=parent_data$province[1],
                                             pid=parent_data$pid[j-1],
                                             year=seq(year_1, first_year, -1),
                                             population=NA)
                        ## the first year should be the same as seen in the data
                        pre_df$population[1] <- pop_1
                        ## for remaining years just divide by the increase rate
                        for(k in 2:nrow(pre_df)){
                            pre_df$population[k] <-  pre_df$population[k-1] / increase_rate
                        }
                        interp_df <- interp_df %>%
                            filter(year > year_1) %>%
                            bind_rows(pre_df) %>%
                            arrange(year)
                    }
                }
                tmp_dat <- bind_rows(tmp_dat,interp_df)
            }
        }
        ## put together the rows for each province
        annual_population <- bind_rows(annual_population, tmp_dat) %>%
            filter(year >= first_year, year<=last_year) %>%
            mutate(population=ceiling(population)
            ) %>%
            filter(!is.na(population)) %>%
            distinct %>%
            arrange(province, year)
    }

    return(annual_population)
}
