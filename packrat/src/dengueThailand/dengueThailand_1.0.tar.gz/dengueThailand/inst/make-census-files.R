## make Thai census interpolations
## by Stephen Lauer, February 2017

#' Find Thai annual population
#' Interpolates populations between census dates. This currently does not account for split provinces
#'
#' @param first_year first year of interest
#' @param last_year last year of interest, if unspecified is present year
#'
#' @return data frame with province, year, and population
find_annual_population <- function(first_year,
                                   last_year,
                                   loc = c("Thailand", "San Juan")) {
    library(XML)
    library(tidyr)
    library(dplyr)
    library(lubridate)

    if(missing(last_year))
        last_year <- year(Sys.Date())

    loc = match.arg(loc)

    if(first_year < 1999)
        warning("This function does not account for split provinces and may not be dependable for years before 1999")

    library(dengueThailand)
    data("thai_prov_data")

    ## read in Thai censes, sort by province, year, and population
    censes <- readHTMLTable("http://www.statoids.com/uth.html",
                            which = 3,
                            stringsAsFactors = FALSE) %>%
        gather("variable", "value", 2:8) %>%
        mutate(year = year(as.Date(variable)),
               Population = as.numeric(gsub(",", "", value)),
               pid = thai_prov_data$FIPS[match(Province, thai_prov_data$Province)]) %>%
        filter(!is.na(Population),
               !is.na(pid),
               year >= min(10 * (floor((first_year - 1) / 10)),
                           2000)) %>%
        select(Province, pid, year, Population) %>%
        mutate(pid = ifelse(Province=="Udon Thani" & year <1999,
                            "TH19", as.character(pid)),
               pid = ifelse(Province=="Prachin Buri" & year <1999,
                            "TH45", as.character(pid)),
               pid = ifelse(Province=="Ubon Ratchathani" & year <1999,
                            "TH71", as.character(pid)),
               pid = ifelse(Province=="Nakhon Phanom" & year <1999,
                            "TH21", as.character(pid)))

    if(1990 %in% unique(censes$year) & 2000 %in% unique(censes$year)){
        udon_thani <- expand.grid(pid=c("TH76", "TH79", "TH19"),
                                  year=unique(censes$year)) %>%
            left_join(censes) %>%
            filter(year<=2000) %>%
            group_by(year) %>%
            summarise(Province = "Udon Thani",
                      pid = "TH19",
                      Population = sum(Population, na.rm=T)) %>%
            select(Province, pid, year, Population)

        nakhon_phanom <- expand.grid(pid=c("TH73", "TH78", "TH21"),
                                     year=unique(censes$year)) %>%
            left_join(censes) %>%
            filter(year<=2000) %>%
            group_by(year) %>%
            summarise(Province = "Nakhon Phanom",
                      pid = "TH21",
                      Population = sum(Population, na.rm=T)) %>%
            select(Province, pid, year, Population)

        prachin_buri <- expand.grid(pid=c("TH80", "TH74", "TH45"),
                                    year=unique(censes$year)) %>%
            left_join(censes) %>%
            filter(year<=2000) %>%
            group_by(year) %>%
            summarise(Province = "Prachin Buri",
                      pid = "TH45",
                      Population = sum(Population, na.rm=T)) %>%
            select(Province, pid, year, Population)

        ubon_ratchathani <- expand.grid(pid=c("TH75", "TH77", "TH71"),
                                        year=unique(censes$year)) %>%
            left_join(censes) %>%
            filter(year<=2000) %>%
            group_by(year) %>%
            summarise(Province = "Ubon Ratchathani",
                      pid = "TH71",
                      Population = sum(Population, na.rm=T)) %>%
            select(Province, pid, year, Population)

        censes <- censes %>%
            filter(!pid %in% c("TH19", "TH45", "TH71", "TH21")) %>%
            bind_rows(udon_thani) %>%
            bind_rows(prachin_buri) %>%
            bind_rows(ubon_ratchathani) %>%
            bind_rows(nakhon_phanom)
    }

    ## create a data frame of all interpolated populations
    annual_population <- c()

    for(i in 1:length(unique(censes$pid))){
        ## look only at one province at a time
        prov_censes <- filter(censes, pid == unique(censes$pid)[i])
        for(j in 2:dim(prov_censes)[1]){
            ## look at two consecutive census dates
            year_1 <- sort(prov_censes$year)[j-1]
            year_2 <- sort(prov_censes$year)[j]
            ## find populations from each census date
            pop_1 <- prov_censes$Population[prov_censes$year == year_1]
            pop_2 <- prov_censes$Population[prov_censes$year == year_2]
            ## find annual rate of increase from early date to later date (negative means decreasing population)
            increase_rate <- (pop_2 / pop_1) ^ (1/(year_2 - year_1))

            ## create a data frame for the province between the two years of interest
            interp_df <- data_frame(Province = prov_censes$Province[1],
                                    pid = prov_censes$pid[1],
                                    year = seq(year_1, year_2 - 1), ## minus one so that don't duplicate years
                                    Population = NA)

            ## for the last two census dates, have the year run to the present
            if(j == dim(prov_censes)[1]){
                interp_df <- data_frame(Province = prov_censes$Province[1],
                                        pid = prov_censes$pid[1],
                                        year = seq(year_1, last_year),
                                        Population = NA)
            }

            ## the first year should be the same as seen in the data
            interp_df$Population[1] <- pop_1
            ## for remaining years just multiply by the increase rate
            for(k in 2:dim(interp_df)[1]){
                interp_df$Population[k] <- increase_rate * interp_df$Population[k-1]
            }

            ## if first_year < the first census year, interpolate first rates backwards
            if(j == 2 & year_1 > first_year) {
                pre_df <- data_frame(Province = prov_censes$Province[1],
                                     pid = prov_censes$pid[1],
                                     year = seq(year_1, first_year, -1),
                                     Population = NA)
                ## the first year should be the same as seen in the data
                pre_df$Population[1] <- pop_1
                ## for remaining years just divide by the increase rate
                for(k in 2:dim(pre_df)[1]){
                    pre_df$Population[k] <-  pre_df$Population[k-1] / increase_rate
                }
                interp_df <- interp_df %>%
                    filter(year > year_1) %>%
                    bind_rows(pre_df) %>%
                    arrange(year)
            }
            ## put together the rows for each province and census pair
            annual_population <- bind_rows(annual_population, interp_df) %>%
                filter(year >= first_year, year<=last_year) %>%
                mutate(Population = ceiling(Population),
                       Population = ifelse(pid=="TH19"&year>=1999,NA,Population),
                       Population = ifelse(pid=="TH45"&year>=1999,NA,Population),
                       Population = ifelse(pid=="TH71"&year>=1999,NA,Population),
                       Population = ifelse(pid=="TH21"&year>=1999,NA,Population),
                       Population = ifelse(pid=="TH74"&year<1999,NA,Population),
                       Population = ifelse(pid=="TH80"&year<1999,NA,Population),
                       Population = ifelse(pid=="TH75"&year<1999,NA,Population),
                       Population = ifelse(pid=="TH77"&year<1999,NA,Population),
                       Population = ifelse(pid=="TH76"&year<1999,NA,Population),
                       Population = ifelse(pid=="TH79"&year<1999,NA,Population),
                       Population = ifelse(pid=="TH78"&year<1999,NA,Population),
                       Population = ifelse(pid=="TH73"&year<1999,NA,Population)) %>%
                filter(!is.na(Population))
        }
    }

    return(annual_population)
}

