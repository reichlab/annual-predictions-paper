library(testthat)
library(pROC)

test_check("pROC")
