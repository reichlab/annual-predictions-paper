library(testthat)
library(ggplot2)

test_check("ggplot2")
